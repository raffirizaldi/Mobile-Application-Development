import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'firebase_options.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const InventoryApp());
}

class InventoryApp extends StatelessWidget {
  const InventoryApp({super.key});


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Inventory App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const InventoryHomePage(),
    );
  }
}

class InventoryHomePage extends StatefulWidget {
  const InventoryHomePage({super.key});

  @override
  _InventoryHomePageState createState() => _InventoryHomePageState();
}

class _InventoryHomePageState extends State<InventoryHomePage> {
  // Firestore Collection Reference
  final CollectionReference _itemsCollection =
      FirebaseFirestore.instance.collection('items');

  // Controller untuk tambah/edit item
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _categoryController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _supplierController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _minStockController = TextEditingController();
  final TextEditingController _quantityInController = TextEditingController();
  final TextEditingController _quantityOutController = TextEditingController();

  // Fungsi tambah item ke Firestore
  Future<void> _addItem() async {
    if (_nameController.text.isEmpty || _quantityController.text.isEmpty)
      return;

    await _itemsCollection.add({
      'name': _nameController.text,
      'quantity': int.tryParse(_quantityController.text) ?? 0,
      'description': _descriptionController.text,
      'category': _categoryController.text,
      'price': double.tryParse(_priceController.text) ?? 0.0,
      'supplier': _supplierController.text,
      'location': _locationController.text,
      'minStock': int.tryParse(_minStockController.text) ?? 0,
      'lastUpdated': FieldValue.serverTimestamp(),
      'quantityIn': int.tryParse(_quantityInController.text) ?? 0,
      'quantityOut': int.tryParse(_quantityOutController.text) ?? 0,
      'createdAt': FieldValue.serverTimestamp(),
    });

    _clearInputFields();
  }

  // Fungsi edit item di Firestore
  Future<void> _editItem(String docId) async {
    if (_nameController.text.isEmpty || _quantityController.text.isEmpty)
      return;

    await _itemsCollection.doc(docId).update({
      'name': _nameController.text,
      'quantity': int.tryParse(_quantityController.text) ?? 0,
      'description': _descriptionController.text,
      'category': _categoryController.text,
      'price': double.tryParse(_priceController.text) ?? 0.0,
      'supplier': _supplierController.text,
      'location': _locationController.text,
      'minStock': int.tryParse(_minStockController.text) ?? 0,
      'lastUpdated': FieldValue.serverTimestamp(),
      'quantityIn': int.tryParse(_quantityInController.text) ?? 0,
      'quantityOut': int.tryParse(_quantityOutController.text) ?? 0,
    });

    _clearInputFields();
  }

  // Fungsi hapus item dari Firestore
  Future<void> _deleteItem(String docId) async {
    await _itemsCollection.doc(docId).delete();
  }

  // Clear input fields
  void _clearInputFields() {
    _nameController.clear();
    _quantityController.clear();
    _descriptionController.clear();
    _categoryController.clear();
    _priceController.clear();
    _supplierController.clear();
    _locationController.clear();
    _minStockController.clear();
    _quantityInController.clear();
    _quantityOutController.clear();
  }

  // Show bottom sheet untuk tambah/edit
  void _showBottomSheet(
      {String? docId,
      String? name,
      int? quantity,
      String? description,
      String? category,
      double? price,
      String? supplier,
      String? location,
      int? minStock,
      int? quantityIn,
      int? quantityOut}) {
    if (docId != null) {
      _nameController.text = name ?? '';
      _quantityController.text = quantity?.toString() ?? '';
      _descriptionController.text = description ?? '';
      _categoryController.text = category ?? '';
      _priceController.text = price?.toString() ?? '';
      _supplierController.text = supplier ?? '';
      _locationController.text = location ?? '';
      _minStockController.text = minStock?.toString() ?? '';
      _quantityInController.text = quantityIn?.toString() ?? '';
      _quantityOutController.text = quantityOut?.toString() ?? '';
    } else {
      _clearInputFields();
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor:
          Colors.transparent, // Membuat background modal transparan
      barrierColor: Colors.transparent, // Menghilangkan overlay gelap
      builder: (BuildContext context) {
        return Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white, // Latar belakang konten tetap putih
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 8,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(16),
                width: MediaQuery.of(context).size.width * 0.9,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text(
                        docId == null ? 'Add Item' : 'Edit Item',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _nameController,
                      decoration: const InputDecoration(labelText: 'Name'),
                    ),
                    TextField(
                      controller: _quantityController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Quantity'),
                    ),
                    TextField(
                      controller: _descriptionController,
                      decoration:
                          const InputDecoration(labelText: 'Description'),
                    ),
                    TextField(
                      controller: _categoryController,
                      decoration: const InputDecoration(labelText: 'Category'),
                    ),
                    TextField(
                      controller: _priceController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Price'),
                    ),
                    TextField(
                      controller: _supplierController,
                      decoration: const InputDecoration(labelText: 'Supplier'),
                    ),
                    TextField(
                      controller: _locationController,
                      decoration: const InputDecoration(labelText: 'Location'),
                    ),
                    TextField(
                      controller: _minStockController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Min Stock'),
                    ),
                    TextField(
                      controller: _quantityInController,
                      keyboardType: TextInputType.number,
                      decoration:
                          const InputDecoration(labelText: 'Quantity In'),
                    ),
                    TextField(
                      controller: _quantityOutController,
                      keyboardType: TextInputType.number,
                      decoration:
                          const InputDecoration(labelText: 'Quantity Out'),
                    ),
                    const SizedBox(height: 20),
                    Center(
                      child: ElevatedButton(
                        onPressed: () {
                          if (docId == null) {
                            _addItem();
                          } else {
                            _editItem(docId);
                          }
                          Navigator.of(context).pop();
                        },
                        child: Text(docId == null ? 'Add' : 'Update'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Inventory App',
          style: TextStyle(
            fontSize: 32,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _itemsCollection
                  .orderBy('createdAt', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return const Center(child: Text('Error loading data'));
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                final items = snapshot.data!.docs;

                return ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    final item = items[index];
                    final docId = item.id;
                    final name = item['name'];
                    final quantity = item['quantity'];
                    final description = item['description'];
                    final category = item['category'];
                    final price = item['price'];
                    final supplier = item['supplier'];
                    final location = item['location'];
                    final minStock = item['minStock'];
                    final quantityIn = item['quantityIn'];
                    final quantityOut = item['quantityOut'];

                    return Card(
                      margin: const EdgeInsets.all(10),
                      child: ListTile(
                        title: Text(
                          name,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Quantity: $quantity'),
                            Text('Description: $description'),
                            Text('Category: $category'),
                            Text('Price: Rp $price'),
                            Text('Supplier: $supplier'),
                            Text('Location: $location'),
                            Text('Min Stock: $minStock'),
                            Text('Quantity In: $quantityIn'),
                            Text('Quantity Out: $quantityOut'),
                          ],
                        ),
                        trailing: SizedBox(
                          width: 100,
                          child: Row(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit),
                                onPressed: () => _showBottomSheet(
                                  docId: docId,
                                  name: name,
                                  quantity: quantity,
                                  description: description,
                                  category: category,
                                  price: price,
                                  supplier: supplier,
                                  location: location,
                                  minStock: minStock,
                                  quantityIn: quantityIn,
                                  quantityOut: quantityOut,
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete),
                                onPressed: () => _deleteItem(docId),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showBottomSheet(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
